<?php namespace Tests;

class CourseViewedTest extends TestCase {}