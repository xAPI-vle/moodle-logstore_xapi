<?php namespace MXTranslator;

class UnnecessaryEvent extends Exception {
    
}